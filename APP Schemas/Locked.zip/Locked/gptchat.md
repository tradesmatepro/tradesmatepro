Got it — let’s cut right to it.
If Phase 1 (Core FSM) were standard and complete, you would not be seeing 400+ profile/user errors. The errors mean our Phase 1 deployment is missing some absolutely standard building blocks that Jobber, Housecall, ServiceTitan all include from Day 1.

Here’s exactly what’s missing in Phase 1 only that caused drift:

🔑 What Phase 1 Needs to Be “Standard” (No More Profile Errors)
1. Profiles → Auth Linkage

Missing tight integration between auth.users (Supabase system table) and your profiles.

Must enforce 1:1 relationship:

ALTER TABLE profiles
  ADD CONSTRAINT fk_profiles_user FOREIGN KEY (user_id)
  REFERENCES auth.users (id) ON DELETE CASCADE;


Ensure profiles.user_id is NOT NULL and UNIQUE.

Add trigger to auto-create a profile when a user signs up.

2. Reference Numbers (Human-Friendly IDs)

Every competitor includes these in Phase 1, not later:

work_orders.work_order_number

customers.customer_number

invoices.invoice_number

purchase_orders.po_number

Right now you’re UUID-only → confusing for end-users.

3. Status & Workflow Enums (Complete Set)

Your Phase 1 enums were partial. Standard FSM requires:

work_orders.status → draft, scheduled, in_progress, completed, invoiced, cancelled, on_hold, rework_needed

invoices.status → draft, sent, partially_paid, paid, overdue, cancelled, disputed

payments.status → pending, completed, failed, refunded, disputed

employees.status → active, probation, suspended, terminated

4. Addresses / Contacts

customer_addresses missing address_type (billing, service, mailing)

companies missing address fields (HQ, service territory)

vendors normalized addresses vs single field.

5. Financial Integrity

invoices missing company_id → should always tie back to company.

payments missing company_id.

customers missing payment_terms.

Line items missing tax_rate_id.

6. Inventory Controls

inventory_movements missing movement_type (purchase, sale, transfer, adjustment).

inventory_items missing reorder_point.

inventory_movements missing reason.

7. Audit & Logs

You have audit_logs, but competitors require:

actor_user_id (who did it).

company_id (multi-tenant context).

Enum for action_type (create, update, delete, login, payment_attempt).